#include <iostream>

long long calcularFatorial(int n) {
    if (n == 0)
        return 1;
    else
        return n * calcularFatorial(n - 1);
}

int main() {
    int numero;
    std::cout << "Digite um numero inteiro nao negativo: ";
    std::cin >> numero;

    if (numero < 0) {
        std::cout << "Numero invalido! Por favor, digite um numero nao negativo.";
        return 1;
    }

    long long fatorial = calcularFatorial(numero);
    std::cout << "O fatorial de " << numero << " eh: " << fatorial;

    return 0;
}
