#include <iostream>
#include <iomanip>

double calcularConstanteA() {
    double e = 1.0;
    double termo = 1.0;
    for (int i = 1; i <= 10; ++i) {
        termo /= i;
        e += termo;
    }
    return e;
}

double calcularConstanteB() {
    double ex = 1.0;
    double x = 1.0;
    double termo = 1.0;
    for (int i = 1; i <= 10; ++i) {
        termo *= x / i;
        ex += termo;
    }
    return ex;
}

int main() {
    std::cout << std::setprecision(15) << "Constante matematica e: " << calcularConstanteA() << std::endl;
    std::cout << std::setprecision(15) << "Constante matematica ex: " << calcularConstanteB() << std::endl;
    return 0;
}
