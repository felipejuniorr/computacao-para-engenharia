#include <iostream>

int main() {
    int numeroProduto;
    double totalVenda = 0.0;

    while (true) {
        std::cout << "Digite o numero do produto (1 a 5) ou -1 para encerrar: ";
        std::cin >> numeroProduto;

        if (numeroProduto == -1)
            break;

        int quantidade;
        switch (numeroProduto) {
            case 1:
                totalVenda += 2.98;
                break;
            case 2:
                totalVenda += 4.50;
                break;
            case 3:
                totalVenda += 9.98;
                break;
            case 4:
                totalVenda += 4.49;
                break;
            case 5:
                totalVenda += 6.87;
                break;
            default:
                std::cout << "Produto nao reconhecido. Tente novamente." << std::endl;
        }
    }

    std::cout << "Total de vendas: R$ " << totalVenda << std::endl;

    return 0;
}
