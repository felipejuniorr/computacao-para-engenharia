#include <iostream>

int main() {
    int numeros[5];

    std::cout << "Digite cinco numeros entre 1 e 30:" << std::endl;
    for (int i = 0; i < 5; ++i) {
        std::cin >> numeros[i];
    }

    std::cout << "Graficos de barras:" << std::endl;
    for (int i = 0; i < 5; ++i) {
        std::cout << "Numero " << (i+1) << ": ";
        for (int j = 0; j < numeros[i]; ++j) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }

    return 0;
}
