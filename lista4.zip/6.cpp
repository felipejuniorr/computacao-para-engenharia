#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    srand(time(NULL));
    int numeroAdivinhado;
    int tentativas = 0;
    int palpite;

    int numeroSecreto = rand() % 100 + 1;

    std::cout << "Pense em um numero entre 1 e 100. Vou tentar adivinhar!" << std::endl;

    do {
        palpite = rand() % 100 + 1;
        std::cout << "Estou pensando no numero " << palpite << ". Este e o numero que voce pensou? (1: Sim, 2: Meu numero e menor, 3: Meu numero e maior): ";
        std::cin >> numeroAdivinhado;
        ++tentativas;

        if (numeroAdivinhado == 2) {
            std::cout << "Seu numero e menor!" << std::endl;
        } else if (numeroAdivinhado == 3) {
            std::cout << "Seu numero e maior!" << std::endl;
        }
    } while (palpite != numeroSecreto && tentativas < 7);

    if (palpite == numeroSecreto) {
        std::cout << "Adivinhei! O numero era " << palpite << "." << std::endl;
    } else {
        std::cout << "Parece que seu numero era muito dificil para mim!" << std::endl;
    }

    return 0;
}
