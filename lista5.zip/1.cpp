#include <iostream>
#include <iomanip>

using namespace std;

// Fun��o para converter Celsius para Fahrenheit
double celsius_para_fahrenheit(double celsius) {
    return (celsius * 9/5) + 32;
}

// Fun��o para imprimir a tabela
void imprimir_tabela() {
    cout << setw(8) << left << "Celsius" << setw(12) << "Fahrenheit" << endl;
    for (int celsius = 0; celsius <= 100; ++celsius) {
        double fahrenheit = celsius_para_fahrenheit(celsius);
        cout << setw(8) << left << celsius << fixed << setprecision(1) << setw(12) << fahrenheit << endl;
    }
}

int main() {
    imprimir_tabela();
    return 0;
}
