#include <iostream>
#include <vector>

using namespace std;

// Fun��o para verificar se um n�mero � perfeito
bool eh_perfeito(int numero) {
    int soma = 1; // Come�a com 1 porque todo n�mero � divis�vel por 1
    for (int i = 2; i * i <= numero; ++i) {
        if (numero % i == 0) {
            soma += i;
            if (i != numero / i) { // Evita contar o mesmo fator duas vezes (a n�o ser que seja um quadrado perfeito)
                soma += numero / i;
            }
        }
    }
    return soma == numero;
}

// Fun��o para imprimir todos os n�meros perfeitos entre 1 e 1000
void imprimir_numeros_perfeitos() {
    cout << "N�meros perfeitos entre 1 e 1000:" << endl;
    for (int i = 2; i <= 1000; ++i) {
        if (eh_perfeito(i)) {
            cout << i << " ";
            cout << "(fatores: ";
            vector<int> fatores;
            for (int j = 1; j < i; ++j) {
                if (i % j == 0) {
                    fatores.push_back(j);
                }
            }
            for (size_t k = 0; k < fatores.size(); ++k) {
                cout << fatores[k];
                if (k != fatores.size() - 1) {
                    cout << " + ";
                }
            }
            cout << ")" << endl;
        }
    }
}

int main() {
    imprimir_numeros_perfeitos();
    return 0;
}
