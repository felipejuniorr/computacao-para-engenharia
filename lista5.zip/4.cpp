#include <iostream>
#include <cstdlib>
#include <ctime>
#include <utility>

using namespace std;

// Fun��o para gerar uma nova pergunta de multiplica��o
pair<int, int> generateQuestion() {
    srand(time(NULL)); // Inicializa a semente do gerador de n�meros aleat�rios
    int num1 = rand() % 9 + 1; // Gera um n�mero aleat�rio entre 1 e 9
    int num2 = rand() % 9 + 1; // Gera outro n�mero aleat�rio entre 1 e 9
    return make_pair(num1, num2);
}

int main() {
    while (true) {
        // Gera uma nova pergunta
        pair<int, int> question = generateQuestion();
        int num1 = question.first;
        int num2 = question.second;
        
        // Exibe a pergunta
        cout << "Quanto e " << num1 << " vezes " << num2 << "? ";
        
        // Recebe a resposta do usu�rio
        int answer;
        cin >> answer;
        
        // Verifica se a resposta est� correta
        if (answer == num1 * num2) {
            cout << "Muito bom!" << endl;
        } else {
            cout << "Nao. Por favor, tente novamente." << endl;
            
            // Permite que o aluno tente novamente at� acertar
            while (true) {
                cout << "Quanto e " << num1 << " vezes " << num2 << "? ";
                cin >> answer;
                if (answer == num1 * num2) {
                    cout << "Muito bom!" << endl;
                    break;
                } else {
                    cout << "Nao. Por favor, tente novamente." << endl;
                }
            }
        }
    }
    return 0;
}
