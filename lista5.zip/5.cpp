#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() {
    srand(time(NULL)); // Inicializa a semente do gerador de n�meros aleat�rios

    char jogarNovamente;
    do {
        int numeroAdivinhado = rand() % 1000 + 1; // Escolhe um n�mero aleat�rio entre 1 e 1000
        int palpite;
        int tentativas = 0;

        cout << "Eu tenho um numero entre 1 e 1000." << endl;
        cout << "Voce consegue adivinhar o meu numero?" << endl;
        
        // Loop para permitir m�ltiplos palpites
        do {
            cout << "Digite seu palpite: ";
            cin >> palpite;
            tentativas++;

            if (palpite == numeroAdivinhado) {
                cout << "Excelente! Voce adivinhou o numero!" << endl;
                cout << "Voce gostaria de jogar novamente (s ou n)? ";
                cin >> jogarNovamente;
            } else if (palpite < numeroAdivinhado) {
                cout << "Muito baixo. Tente novamente." << endl;
            } else {
                cout << "Muito alto. Tente novamente." << endl;
            }
        } while (palpite != numeroAdivinhado);

    } while (jogarNovamente == 's');

    return 0;
}
