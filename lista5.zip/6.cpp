#include <iostream>

using namespace std;

// Funcao recursiva para mover discos
void mover_discos(int num_discos, int estaca_origem, int estaca_destino, int estaca_temporaria) {
    if (num_discos == 1) {
        cout << estaca_origem << " -> " << estaca_destino << endl;
        return;
    }
    
    // Move (num_discos - 1) discos da estaca origem para a estaca temporaria usando a estaca destino como temporaria
    mover_discos(num_discos - 1, estaca_origem, estaca_temporaria, estaca_destino);
    
    // Move o ultimo disco da estaca origem para a estaca destino
    cout << estaca_origem << " -> " << estaca_destino << endl;
    
    // Move (num_discos - 1) discos da estaca temporaria para a estaca destino usando a estaca origem como temporaria
    mover_discos(num_discos - 1, estaca_temporaria, estaca_destino, estaca_origem);
}

int main() {
    int num_discos;
    cout << "Digite o numero de discos: ";
    cin >> num_discos;

    cout << "Instrucoes para mover os discos:" << endl;
    mover_discos(num_discos, 1, 3, 2);

    return 0;
}
